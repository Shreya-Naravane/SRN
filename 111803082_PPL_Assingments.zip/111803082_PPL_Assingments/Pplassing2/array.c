#include<stdio.h>
int main(){
	char arr[5];
	int i;
	for(i=0;i<20;i++){
		arr[i]='a';
	}
	return 0;
}

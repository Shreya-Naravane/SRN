class cat():
	def __init__(self,a="black"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Meow")
	def walk(self):
		print("walk or crawl")
c1=cat()
p=c1.get_legs()
print(p)
c1.speak()
	
class dog():
	def __init__(self,a="brown"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Barks")
	def walk(self):
		print("Run or walk")
d1=dog()
p=d1.get_legs()
print(p)
d1.speak()

class horse():
	def __init__(self,a="white"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Nheighs")
	def walk(self):
		print("Run or walk")
h1=cat()
p=h1.get_legs()
print(p)
h1.speak()

class cow():
	def __init__(self,a="white"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Moo's")
	def walk(self):
		print("Walk ")
C1=cow()
p=C1.get_legs()
print(p)
C1.speak()

class elephant():
	def __init__(self,a="grey"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Trumpets")
	def walk(self):
		print("Walk")
e1=elephant()
p=e1.get_legs()
print(p)
e1.speak()	


class lion():
	def __init__(self,a="yellow"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Roars")
	def walk(self):
		print("Walks or Runs")
l1=lion()
p=l1.get_legs()
print(p)
l1.speak()	

class tiger():
	def __init__(self,a="Yellow and Black"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("roars")
	def walk(self):
		print("Walks or Runs")
t1=tiger()
p=t1.get_legs()
print(p)
t1.speak()	

class cheetah():
	def __init__(self,a="Yellow"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Growls or purs")
	def walk(self):
		print("Run")
ch1=cheetah()
p=ch1.get_legs()
print(p)
ch1.speak()	

class monkey():
	def __init__(self,a="yellow or black"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("Chatters")
	def walk(self):
		print("Jumps")
m1=monkey()
p=m1.get_legs()
print(p)
m1.speak()	

class rats():
	def __init__(self,a="grey"):
		self.__colour = a
		self.__legs=4
	def get_legs(self):
		return self.__legs
	def set_legs(self,x):
		self.__legs=x
	def set_furcolour(self,b):
		self.__furcolour=b
	def get_furcolour(self):
		return self.__colour
	def speak(self):
		print("squeaks")
	def walk(self):
		print("Runs,crawl or jumps")
r1=rats()
p=r1.get_legs()
print(p)
r1.speak()





	

	

